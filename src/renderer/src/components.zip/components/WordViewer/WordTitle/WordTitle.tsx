import PillBoxList from '../PillBoxList/PillBoxList'
import './WordTitle.css'
import { Word } from '@shared/types'

interface WordTitleProps {
  word: Word
}

function WordTitle({ word }: WordTitleProps): React.JSX.Element {
  return (
    <div className="wordTitle">
      <h1>{word.text}</h1>
      {word.definition && <div>{word.definition}</div>}
      <PillBoxList textArray={word.tags} />
    </div>
  )
}

export default WordTitle
