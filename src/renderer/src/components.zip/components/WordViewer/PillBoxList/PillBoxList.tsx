import PillBox from './PillBox/PillBox'
import './PillBoxList.css'

interface PillBoxListProps {
  textArray: string[]
}

function PillBoxList({ textArray }: PillBoxListProps): React.JSX.Element {
  return (
    <div className="pillBoxList">
      {textArray.map((text, key) => (
        <PillBox key={key} text={text} />
      ))}
    </div>
  )
}

export default PillBoxList
