import './PillBox.css'

interface PillBoxProps {
  text: string
}

function PillBox({ text }: PillBoxProps): React.JSX.Element {
  return <div className="pillBox"> {text} </div>
}

export default PillBox
